Sanity Tests » replace-urlopen
==============================

Use ``open_url`` from ``module_utils`` instead of ``urlopen``.
